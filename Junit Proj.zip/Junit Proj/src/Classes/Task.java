package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

public class Task {
    private final String taskId; // Unique and not updatable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID cannot be null and must be 10 characters or less.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters (excluding Task ID as it's not updatable)
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name cannot be null and must be 20 characters or less.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description cannot be null and must be 50 characters or less.");
        }
        this.description = description;
    }
}
