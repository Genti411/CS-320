package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testCreateAppointmentWithValidData() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // 1 day in the future
        Appointment appointment = new Appointment("12345", futureDate, "Regular check-up");
        assertNotNull(appointment);
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Regular check-up", appointment.getDescription());
    }

    @Test
    void testAppointmentIdConstraints() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Description"));
    }

    @Test
    void testAppointmentDateConstraints() {
        Date pastDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000); // 1 day in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", pastDate, "Description"));
    }

    @Test
    void testAppointmentDescriptionConstraints() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        String longDescription = "a".repeat(51); // 51 characters
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, longDescription));
    }
}
