package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    void testAddTaskWithUniqueID() {
        Task task1 = new Task("task001", "Task One", "Description One");
        taskService.addTask(task1);
        assertEquals(task1, taskService.getTask("task001"));

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Task taskDuplicate = new Task("task001", "Task Duplicate", "Description Duplicate");
            taskService.addTask(taskDuplicate);
        });
        assertTrue(exception.getMessage().contains("task ID already exists"));
    }

    @Test
    void testDeleteTask() {
        Task task = new Task("task002", "Task Two", "Description Two");
        taskService.addTask(task);
        assertNotNull(taskService.getTask("task002"));

        taskService.deleteTask("task002");
        assertNull(taskService.getTask("task002"));
    }

    @Test
    void testUpdateTask() {
        Task task = new Task("task003", "Task Three", "Description Three");
        taskService.addTask(task);
        taskService.updateTask("task003", "Updated Task Three", "Updated Description Three");

        Task updatedTask = taskService.getTask("task003");
        assertNotNull(updatedTask);
        assertEquals("Updated Task Three", updatedTask.getName());
        assertEquals("Updated Description Three", updatedTask.getDescription());
    }
}
