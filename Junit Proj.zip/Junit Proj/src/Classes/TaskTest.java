package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void testTaskCreationWithValidData() {
        String taskId = "task001";
        String name = "Sample Task";
        String description = "This is a sample task description.";
        Task task = new Task(taskId, name, description);
        
        assertNotNull(task);
        assertEquals(taskId, task.getTaskId());
        assertEquals(name, task.getName());
        assertEquals(description, task.getDescription());
    }

    @Test
    void testTaskIdNotNullAndWithinLength() {
        String tooLongTaskId = "task12345678901";
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task(tooLongTaskId, "Task", "Description"));
    }

    @Test
    void testTaskNameNotNullAndWithinLength() {
        String tooLongName = "This is a very long task name exceeding twenty characters";
        assertThrows(IllegalArgumentException.class, () -> new Task("task002", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("task002", tooLongName, "Description"));
    }

    @Test
    void testTaskDescriptionNotNullAndWithinLength() {
        String tooLongDescription = "This is a very long task description that exceeds the limit of fifty characters";
        assertThrows(IllegalArgumentException.class, () -> new Task("task003", "Task", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("task003", "Task", tooLongDescription));
    }
}
