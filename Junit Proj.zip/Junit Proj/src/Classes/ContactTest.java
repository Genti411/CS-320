package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactTest {

    @Test
    void testContactIdConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    void testFirstNameConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", null, "Doe", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Johnathan", "Doe", "1234567890", "123 Main St"));
    }

    @Test // Added the missing @Test annotation here
    void testLastNameConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", null, "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "DoeDoeDoeDoe", "1234567890", "123 Main St"));
    }

    @Test
    void testPhoneConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", null, "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "123456789", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "12345678901", "123 Main St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "abcdefghij", "123 Main St"));
    }

    @Test
    void testAddressConstraints() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "1234567890", "123 Main Street, Springfield, State, Country"));
    }
}
