// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//
package Classes;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddUniqueAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000); // 1 day in the future
        Appointment appointment1 = new Appointment("001", futureDate, "Checkup");
        appointmentService.addAppointment(appointment1);
        assertEquals(appointment1, appointmentService.getAppointment("001"));

        // Test adding appointment with duplicate ID
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Appointment duplicateAppointment = new Appointment("001", futureDate, "Dentist Visit");
            appointmentService.addAppointment(duplicateAppointment);
        });
        assertTrue(exception.getMessage().contains("Appointment with this ID already exists"));
    }

    @Test
    void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("002", futureDate, "Dental Checkup");
        appointmentService.addAppointment(appointment);
        assertNotNull(appointmentService.getAppointment("002"));

        appointmentService.deleteAppointment("002");
        assertNull(appointmentService.getAppointment("002"));

        // Test deleting non-existent appointment
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("003");
        });
        assertTrue(exception.getMessage().contains("No appointment found with this ID"));
    }
}
