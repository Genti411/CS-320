package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    @Test
    void testAddUniqueContact() {
        Contact contact = new Contact("001", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("001"));

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            Contact duplicateContact = new Contact("001", "Jane", "Doe", "0987654321", "456 Elm St");
            contactService.addContact(duplicateContact);
        });
        assertTrue(exception.getMessage().contains("Contact ID already exists"));
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("002", "Jane", "Doe", "0987654321", "456 Elm St");
        contactService.addContact(contact);
        contactService.deleteContact("002");
        assertNull(contactService.getContact("002"));
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("003", "Mike", "Smith", "1122334455", "789 Oak St");
        contactService.addContact(contact);
        contactService.updateContact("003", "Michael", "Smithers", "5544332211", "987 Maple Ave");
        Contact updatedContact = (Contact) contactService.getContact("003");
        assertNotNull(updatedContact);
        assertEquals("Michael", updatedContact.getFirstName());
        assertEquals("Smithers", updatedContact.getLastName());
        assertEquals("5544332211", updatedContact.getPhone());
        assertEquals("987 Maple Ave", updatedContact.getAddress());
    }
}
