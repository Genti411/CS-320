package Classes;

// 
// Gentian Hoxha
// Gentianhoxha@snhu.edu
// Project 1
// 12/08/2023
//package Classes;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks;

    public TaskService() {
        this.tasks = new HashMap<>();
    }

    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task is null or task ID already exists.");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
        tasks.remove(taskId);
    }

    public void updateTask(String taskId, String newName, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID does not exist.");
        }
        if (newName != null && !newName.isEmpty()) {
            task.setName(newName);
        }
        if (newDescription != null && !newDescription.isEmpty()) {
            task.setDescription(newDescription);
        }
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
